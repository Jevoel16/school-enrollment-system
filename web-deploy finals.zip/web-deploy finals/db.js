const mysql = require('mysql2');
require('dotenv').config();
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST, // Use 'localhost' if MySQL is running locally
    user: process.env.DATABASE_USER, // Replace with your MySQL username
    password: process.env.DATABASE_PASSWORD, // Replace with your MySQL password
    database: process.env.DATABASE // The name of the database you created
});
    
db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to MySQL database.');
});

module.exports = db;