
// public/script.js
document.getElementById('enrollmentForm').addEventListener('submit', addStudent);
document.getElementById('updateForm').addEventListener('submit', updateStudent);
document.getElementById('adminForm').addEventListener('submit', checkPassword);
document.addEventListener('DOMContentLoaded', loadStudent);

function addStudent(e) {
    e.preventDefault();
    const stud_name = document.getElementById('stud_name').value;
    const birthdate = document.getElementById('birthdate').value;
    const address = document.getElementById('address').value;
    const yr_lvl = document.getElementById('yr_lvl').value;
    const section_id = parseInt(document.getElementById('section_id').placeholder);

    fetch('/students', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({stud_name, birthdate, address, yr_lvl, section_id})
    })
    .then(response => response.json())
    .then(data => {
        showNotification(`Student named ${stud_name} has been added.`);
        document.getElementById('section_id').placeholder = "Section";
        console.log('Student added:', data);
        loadStudent();
        document.getElementById('enrollmentForm').reset();
    })
    .catch(error => console.error('Error:', error));
}
function updateStudent(e) {
    e.preventDefault();
    // Handle edit action
    const student_ids = document.getElementById('new_student_id').value;
    const student_id = document.getElementById('new_student_id').placeholder;
    const stud_name = document.getElementById('new_stud_name').value;
    const birthdate = document.getElementById('new_birthdate').value;
    const address = document.getElementById('new_address').value;
    const yr_lvl = document.getElementById('new_yr_lvl').value;
    const section_id = parseInt(document.getElementById('new_section_id').placeholder);
    
    if (confirm(`Are you sure you want to update student ID: ${student_ids}?`)) {
        fetch(`/students/${student_id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({stud_name, birthdate, address, yr_lvl, section_id})
            
        })
        .then(response => response.json())
            .then(data => {
                console.log('Student updated:', data);
                loadStudent();
                showNotification(`Student with ID ${student_ids} has been updated.`);
                openTab(confirm, 'viewStudents');
                currentstudid = student_ids;
                document.getElementById('new_student_id').placeholder = "Student_ID";
                document.getElementById('new_stud_name').placeholder = "New Name";
                document.getElementById('new_yr_lvl').placeholder = "New Year Level";
                document.getElementById('new_address').placeholder = "New Adress";
                document.getElementById('new_section_id').placeholder = "Section";
                document.getElementById('updateForm').reset();
            })
            .catch(error => console.error('Error:', error));
    }
}

async function loadStudent() {
    try {
        const response = await fetch('/students', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        const studentList = document.getElementById('studentList');
        studentList.innerHTML = '';

        data.forEach(student => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${student.student_id}</td>
                <td>${student.stud_name}</td>
                <td>${student.age}</td>
                <td>${student.birthdate}</td>
                <td>${student.address}</td>
                <td>${student.yr_lvl}</td>
                <td>${student.section}</td>
                <td>${student.adviser_name}</td>
                <td>
                    <button type="button" class="update-button" "aria-label="Delete student ID ${student.student_id}">Update</button>
                    <button type="button" class="delete-button" aria-label="Delete student ID ${student.student_id}">Delete</button>
                </td>
            `;
            const updateButton = tr.querySelector('.update-button');
            updateButton.addEventListener('click', (e) => {
                const filterPanel = document.getElementById('filterPanel');
                if (filterPanel.style.display === 'none' || filterPanel.style.display === '') {
                } else {
                    openFilter(e, 'filterPanel');
                }
                if (confirm(`Are you sure you want to update student ID: ${student.student_id}?`)) {
                    openModal();
                    document.getElementById('modalForm').addEventListener('submit', async (e) => {
                            e.preventDefault();
                            const password = document.getElementById('passwordInput').value;
                            if (password == student.password) {
                                document.getElementById('new_student_id').value = student.student_id;
                                document.getElementById('new_student_id').placeholder = student.id;
                                document.getElementById('new_stud_name').placeholder = student.stud_name;
                                document.getElementById('new_birthdate').placeholder = student.birthdate;
                                document.getElementById('new_address').placeholder = student.address;
                                document.getElementById('new_yr_lvl').placeholder = student.yr_lvl;
                                document.getElementById('new_section_id').placeholder = student.section_id;
                                openTab(confirm, 'updateStudent');
                            } else {
                                alert("Wrong Password!!! SUS!");
                                closeModal();
                            }
                            closeModal(); // Close the modal after submission
                            document.getElementById('passwordInput').value = "";
                    }   
            );};
            });

            const button_delete = tr.querySelector('.delete-button');
            button_delete.addEventListener('click', async (e) => {
                const filterPanel = document.getElementById('filterPanel');
                if (filterPanel.style.display === 'none' || filterPanel.style.display === '') {
                } else {
                    openFilter(e, 'filterPanel');
                }
                if (confirm(`Are you sure you want to delete student ID: ${student.student_id}?`)) {
                        openModal();
                        document.getElementById('modalForm').addEventListener('submit', async (e) => {
                            e.preventDefault();
                            const password = document.getElementById('passwordInput').value;
                            if (password == student.password) {
                                try {
                                    const deleteResponse = await fetch(`/students/${student.id}`, {
                                        method: 'DELETE'
                                    });
        
                                    if (deleteResponse.ok) {
                                        loadStudent(); // Reload the student list after deletion
                                        showNotification(`Student with ID ${student.student_id} has been deleted.`);
                                    } else {
                                        console.error('Failed to delete student');
                                    }
                                } catch (error) {
                                    console.error('Error:', error);
                                }
                            } else {
                                alert("Wrong Password!!! SUS!");
                                closeModal();
                            }
                            closeModal(); // Close the modal after submission
                            document.getElementById('passwordInput').value = "";
                        }
                );};
            });

            studentList.appendChild(tr);
        });
    } catch (error) {
        console.error('Error:', error);
        // Optionally display an error message to the user
        alert('Failed to load student data. Please try again later.');
    }
}


function openTab(evt, tabName) {
    // Hide all tab content
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });

    // Remove active class from all tab buttons
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    // Show the current tab and add an active class to the button that opened the tab
    if (tabName == 'viewStudents') {
        document.getElementById(tabName).classList.add('active');
        document.getElementById('view').classList.add('active');
    } 
    if (tabName == 'updateStudent') {
        document.getElementById(tabName).classList.add('active');
        document.getElementById('update').classList.add('active');
    } 
    if (tabName == 'addStudent') {
        document.getElementById(tabName).classList.add('active');
        document.getElementById('add').classList.add('active');
    }
}

// script.js

const searchStud_id = document.getElementById('searchStud_id');
const searchName = document.getElementById('searchName');
const searchAge = document.getElementById('searchAge');
const searchAddress = document.getElementById('searchAddress');
const searchSection = document.getElementById('searchSection');
const searchYear = document.getElementById('searchYear');
const searchAdviser = document.getElementById('searchAdviser');
const studentTable = document.getElementById('studentList');

function filterTable() {
    const queryStud_id = searchStud_id.value;
    const queryName = searchName.value.toLowerCase();
    const queryAge = searchAge.value;
    const queryAddress = searchAddress.value.toLowerCase();
    const querySection = searchSection.value.toLowerCase(); // Ensure case-insensitive comparison
    const queryYear = searchYear.value // Ensure case-insensitive comparison
    const queryAdviser = searchAdviser.value.toLowerCase(); // Ensure case-insensitive comparison
    const rows = studentTable.getElementsByTagName('tr');

    // Loop through the table rows and hide/show based on the search query and selected filters
    for (let i = 0; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        if (cells.length === 0) continue; // Skip empty rows (like the header)

        const stud_idCell = cells[0].textContent; // Age is in the third column
        const nameCell = cells[1].textContent.toLowerCase(); // Assuming the name is in the second column
        const ageCell = cells[2].textContent; // Age is in the third column
        const addressCell = cells[4].textContent.toLowerCase(); // 
        const yearCell = cells[5].textContent.toLowerCase(); // Year Level is in the fourth column
        const sectionCell = cells[6].textContent.toLowerCase(); // Section is in the fifth column
        const adviserCell = cells[7].textContent.toLowerCase(); // Year Level is in the fourth column

        // Check if the row matches the search query
        const matchesStud_id = queryStud_id === '' || stud_idCell.includes(queryStud_id); // Allow empty query to match all
        const matchesName = queryName === '' || nameCell.includes(queryName); // Allow empty query to match all
        const matchesAge = queryAge === '' || ageCell.startsWith(queryAge); // Allow empty query to match all
        const matchesAddress = queryAddress === '' || addressCell.includes(queryAddress); // Allow empty query to match all
        const matchesSection = querySection === '' || sectionCell.startsWith(querySection); // Allow empty query to match all
        const matchesYear = queryYear === '' || yearCell.startsWith(queryYear); // Allow empty query to match all
        const matchesAdviser = queryAdviser === '' || adviserCell.includes(queryAdviser); // Allow empty query to match all

        // Show or hide the row based on the criteria
        if (matchesStud_id && matchesName && matchesAge && matchesAddress && matchesSection && matchesYear && matchesAdviser) {
            rows[i].style.display = ''; // Show the row
        } else {
            rows[i].style.display = 'none'; // Hide the row
        }
    }
}

searchStud_id.addEventListener('input', filterTable);
searchName.addEventListener('input', filterTable);
searchAge.addEventListener('input', filterTable);
searchAddress.addEventListener('input', filterTable);
searchSection.addEventListener('input', filterTable);
searchYear.addEventListener('input', filterTable);
searchAdviser.addEventListener('input', filterTable);

//change filter

function openFilter(evt, tabName) {
    if(tabName == 'filterPanel'){
        const toggleButton = document.getElementById('toggleFilters');
        const filterPanel = document.getElementById('filterPanel');
        if (filterPanel.style.display === 'none' || filterPanel.style.display === '') {
            filterPanel.style.display = 'flex'; // Show the filter panel
            toggleButton.textContent = 'Hide Filters'; // Change button text
        } else {
            filterPanel.style.display = 'none'; // Hide the filter panel
            toggleButton.textContent = 'Show Filters'; // Change button text
        }
    } else {
        const tabContents = document.querySelectorAll('.filter-content');
        tabContents.forEach(content => {
            content.classList.remove('active');
            content.value = '';
        });
    
        // Remove active class from all tab buttons
        const tabButtons = document.querySelectorAll('.filter-button');
            tabButtons.forEach(button => {
            button.classList.remove('active');
        });
        if (tabName == "viewStudents"){
            document.getElementById(tabName).classList.add('active');
            document.getElementById('view').currentTarget.classList.add('active');
        }        
        if (tabName == "updateStudent"){
            document.getElementById(tabName).classList.add('active');
            document.getElementById('update').currentTarget.classList.add('active');
        }else {
        // Show the current tab and add an active class to the button that opened the tab
            document.getElementById(tabName).classList.add('active');
            evt.currentTarget.classList.add('active');
        }
    }
    document.getElementById(tabName).classList.add('active');
    evt.currentTarget.classList.add('active');
    evt.currentTarget.addEventListener('click', filterTable);
}      

function exportToCSV() {
    let csv_data = [];
    let rows = document.querySelectorAll("tr");

    for (let i = 0; i < rows.length; i++) {
        // Check if the row is visible
        if (rows[i].style.display !== 'none') {
            let cols = rows[i].querySelectorAll("td, th");
            let csvrow = [];
            for (let j = 0; j < cols.length - 1; j++) { // Include all columns
                csvrow.push(cols[j].innerText);
            }
            csv_data.push(csvrow.join(",")); // Join columns with a comma
        }
    }

    if (csv_data.length > 0) { // Check if there's any data to export
        let csvString = csv_data.join("\n");
        downloadCSVFile(csvString);
    } else {
        alert("No data available to export.");
    }
}

function downloadCSVFile(csv_data) {
    let CSVFile = new Blob([csv_data], { type: "text/csv" });
    let temp_link = document.createElement("a");
    temp_link.download = "students_data.csv";   
    let url = window.URL.createObjectURL(CSVFile);
    temp_link.href = url;
    temp_link.style.display = "none";
    document.body.appendChild(temp_link);
    temp_link.click();
    document.body.removeChild(temp_link);
}

async function checkPassword(e) {
    e.preventDefault();
    const inputPassword = document.getElementById("password").value;
    const errorMessage = document.getElementById("error-message");
    const protectedContent = document.getElementById("protected-content");

    try {
        const response = await fetch('/check-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ password: inputPassword })
        });

        if (response.ok) {
            // Show protected content
            protectedContent.style.display = "block";
            document.querySelector('.password-container').style.display = "none"; // Hide prompt
        } else {
            const data = await response.json();
            errorMessage.textContent = data.message || "Incorrect password. Please try again.";
        }
    } catch (error) {
        console.error('Error:', error);
        errorMessage.textContent = "An error occurred. Please try again.";
    }
}
// for filter prediction

// for prediction

function searchSuggestionsYearLevel(sectionkey, section, yr_lvl_container){
    const sectionInput = document.getElementById(section);
    const sectionkeyInput = document.getElementById(sectionkey);
    const yr_levelsuggestionsContainer = document.getElementById(yr_lvl_container);

    const years = [1, 2, 3, 4, 5, 6];
        years.forEach(year => {
            if (years) {
                sectionInput.placeholder = "Section";
                sectionInput.value = "";
                const div = document.createElement('div');
                div.classList.add('suggestion-item');
                div.textContent = year; // Display the section name
                div.addEventListener('mouseover', () => {
                    sectionkeyInput.value = year; // Change placeholder to section ID
                });
        
                // Reset the placeholder on mouse out
                div.addEventListener('mouseout', () => {
                    sectionkeyInput.placeholder = 'Year level'; // Reset to default placeholder
                });
                div.addEventListener('click', () => {
                    sectionkeyInput.value = year; // Set input value to the selected section ID
                    yr_levelsuggestionsContainer.innerHTML = ''; // Clear suggestions
                });
                yr_levelsuggestionsContainer.appendChild(div);
            }   else {
                    yr_levelsuggestionsContainer.innerHTML = ''; // Clear suggestions
            }
            sectionkeyInput.addEventListener('blur', () => {
                yr_levelsuggestionsContainer.innerHTML = ''; // Clear suggestions
             });
        })
}
function searchSuggestions(sectionkey, section, container) {
    const sectionkeyInput = document.getElementById(sectionkey);
    const sectionInput = document.getElementById(section);
    const suggestionsContainer = document.getElementById(container);
    const query = sectionkeyInput.value;

    // Clear previous suggestions
    suggestionsContainer.innerHTML = '';
    
    if (query) {
        // Fetch suggestions from the server with the query parameter
        fetch(`/show-sections?query=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                // Clear previous suggestions
                suggestionsContainer.innerHTML = '';

                // Only show suggestions that match the query
                data.forEach(section => {
                    const div = document.createElement('div');
                    div.classList.add('suggestion-item');
                    div.textContent = section.section_name; // Display the section name
                    div.addEventListener('mouseover', () => {
                        sectionInput.placeholder = section.section_id; // Change placeholder to section ID
                        sectionInput.value = section.section_name;
                    });

                    // Reset the placeholder on mouse out
                    div.addEventListener('mouseout', () => {
                        sectionInput.placeholder = 'Section'; // Reset to default placeholder
                    });
                    div.addEventListener('click', () => {
                        sectionInput.placeholder = section.section_id;
                        sectionInput.value = section.section_name; // Set input value to the selected section ID
                        suggestionsContainer.innerHTML = ''; // Clear suggestions
                    });
                    suggestionsContainer.appendChild(div);
                });
                sectionInput.addEventListener('blur', () => {
                    suggestionsContainer.innerHTML = ''; // Clear suggestions
                 });
            })
            .catch(error => {
                console.error('Error fetching sections:', error);
            });
    }
}
// for update and delete message
function showNotification(message) {
    const notification = document.getElementById('notification1');
    notification.textContent = message;
    notification.classList.add('show'); // Add the show class to trigger styles

    // Show the notification
    notification.style.display = 'block';

    // Hide the notification after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show'); // Remove the show class
        // Optionally hide it completely after the transition
        setTimeout(() => {
            notification.style.display = 'none';
        }, 500); // Match this duration with the CSS transition duration
    }, 3000); // Show for 3 seconds
}

//for confirmation
function openModal() {
    document.getElementById('passwordModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('passwordModal').style.display = 'none';
}

