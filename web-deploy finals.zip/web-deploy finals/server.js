// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const CryptoJS = require('crypto-js');
const db = require('./db');
const stud_id = process.env.SECRET_KEY;
const app = express();
const PORT = process.env.PORT;
const correctPassword = process.env.ADMIN_PASSWORD;
const path = require('path');
// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));


// Serve the favicon
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// CRUD Operations

// Add a new student
app.post('/students', (req, res) => {
    const {stud_name,birthdate, address, yr_lvl, section_id} = req.body;
    const stud_names = rebirth(stud_name,stud_id);
    const addresses= rebirth(address, stud_id);
    const birthdates= rebirth(birthdate, stud_id);
    const query = 'INSERT INTO students ( stud_name, birthdate, address, yr_lvl, section_id) VALUES ( ?, ?, ?, ?, ?);';
    db.query(query, [stud_names, birthdates, addresses, yr_lvl, section_id], (err, result) => {
        if (err) {
            return res.status(400).json({ message: err.message });
        }
        res.status(201).json({ student_id: result.insertId, stud_names, birthdates, addresses, yr_lvl, section_id});
    }); 
});

// Retrieve all students
app.get('/students', (req, res) => {
    const query = `SELECT 
            CONCAT(YEAR(CURDATE()), '-', LPAD(students.student_id, 4, '0')) AS student_id,
            students.student_id AS id,
            students.stud_name AS stud_name,
            students.birthdate AS birthdate,
            students.address AS address,
            sections.yr_lvl AS yr_lvl,
            sections.section_id AS section_id,
            sections.section_name AS section,
            instructors.instructor_name AS adviser_name
        FROM
            students
                LEFT JOIN
            sections ON students.section_id = sections.section_id
                LEFT JOIN
            instructors ON sections.adviser_id = instructors.instructor_id
                LEFT JOIN
            year_level ON instructors.yr_lvl = year_level.yr_lvl
        WHERE
            students.yr_lvl = year_level.yr_lvl`;
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        } 
        const decryptedResults = results.map(student => {
            return {
                password: correctPassword,
                id: student.id,
                student_id: student.student_id,
                stud_name: renounce(student.stud_name, stud_id),
                age: calculateAge(renounce(student.birthdate, stud_id)),
                birthdate: renounce(student.birthdate, stud_id),
                address: renounce(student.address, stud_id),
                yr_lvl: student.yr_lvl,
                section_id: student.section_id,
                section: renounce(student.section, stud_id),
                adviser_name: renounce(student.adviser_name, stud_id)
            };
        });
        res.status(200).json(decryptedResults);
    });
});

// Update a student
app.put('/students/:student_id', (req, res) => {
    const { student_id } = req.params;
    const { stud_name, birthdate, address, yr_lvl, section_id} = req.body;
    const stud_names = rebirth(stud_name,stud_id);
    const addresses= rebirth(address, stud_id);
    const birthdates= rebirth(birthdate, stud_id);
    const query = 'UPDATE students SET stud_name = ?, birthdate = ?, address = ?, yr_lvl = ?, section_id = ? WHERE student_id = ?';
    db.query(query, [stud_names, birthdates, addresses, yr_lvl, section_id, student_id], (err) => {
        if (err) {
            return res.status(400).json({ message: err.message });
        }
        res.status(200).json({student_id , stud_names, birthdates, addresses,  yr_lvl, section_id});
    });
});

// Delete a student
app.delete('/students/:student_id', (req, res) => {
    const { student_id } = req.params;
    const query = 'DELETE FROM students WHERE student_id = ?';
    db.query(query, [student_id], (err) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        }
            res.status(204).send();
    });
});

function rebirth(data, key) {
    // Generate a random Initialization Vector (IV)
    const iv = CryptoJS.lib.WordArray.random(16);
    
    // Encrypt the data using AES with the provided key and IV
    const encrypted = CryptoJS.AES.encrypt(data, CryptoJS.enc.Hex.parse(key), {
        iv: iv,
        padding: CryptoJS.pad.Pkcs7,
        mode: CryptoJS.mode.CBC,
    });

    // Concatenate IV and ciphertext and encode in Base64 format
    const cipherText = CryptoJS.enc.Base64.stringify(iv.concat(encrypted.ciphertext));
    return cipherText;
}


function renounce(cipherText, key) {
    try {
        // Decode the Base64 string
        const fullCipher = CryptoJS.enc.Base64.parse(cipherText);
        
        // Extract IV and ciphertext
        const iv = CryptoJS.lib.WordArray.create(fullCipher.words.slice(0, 4), 16);
        const ciphertext = CryptoJS.lib.WordArray.create(fullCipher.words.slice(4));

        // Create cipher parameters for decryption
        const cipherParams = CryptoJS.lib.CipherParams.create({
            ciphertext: ciphertext,
        });

        // Decrypt the ciphertext using AES with the provided key and IV
        const bytes = CryptoJS.AES.decrypt(cipherParams, CryptoJS.enc.Hex.parse(key), {
            iv: iv,
            padding: CryptoJS.pad.Pkcs7,
            mode: CryptoJS.mode.CBC,
        });

        // Check if decryption was successful and return the decrypted data
        if (bytes.sigBytes > 0) {
            const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
            return decryptedData;
        } else {
            throw new Error("Decryption Failed: Invalid Key or Data");
        }
    } catch (error) {
        throw new Error("Decryption Failed: " + error.message);
    }
}

app.post('/check-password', (req, res) => {
    const { password } = req.body;
    if (password === correctPassword) {
        res.status(200).json({ success: true });
    } else {
        res.status(401).json({ success: false, message: 'Incorrect password' });
    }
});

app.get('/show-sections', (req, res) => {
    const query = req.query.query || ''; // Get the query parameter
    const sqlQuery = `SELECT 	
            year_level.yr_lvl AS yr_lvl,
            sections.yr_lvl as sections_yr_lvl,
            sections.section_id AS section_id,
            sections.section_name AS section_name
        FROM
            sections 
                LEFT JOIN
            year_level ON sections.yr_lvl = year_level.yr_lvl
        WHERE
            year_level.yr_lvl LIKE ?`; // Use LIKE for partial matching

    db.query(sqlQuery, [`%${query}%`], (err, results) => {
        if (err) {
            return res.status(500).json({ message: err.message });
        } 
        const decryptedResults = results.map(section => {
            return {
                yr_lvl: section.yr_lvl,
                sections_yr_lvl: section.sections_yr_lvl,
                section_id: section.section_id,
                section_name: `${section.section_id} - ${renounce(section.section_name, stud_id)}`
            };
        });
        res.status(200).json(decryptedResults);
    });
});

//for automatic age

function calculateAge(birthDate) {
    const today = new Date(); // Get the current date
    const birth = new Date(birthDate); // Convert the input date to a Date object

    let age = today.getFullYear() - birth.getFullYear(); // Calculate the initial age difference

    // Adjust age if the birthday hasn't occurred yet this year
    const monthDifference = today.getMonth() - birth.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birth.getDate())) {
        age--;
    }

    return age; // Return the calculated age
}


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
}); 
